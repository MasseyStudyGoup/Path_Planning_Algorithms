#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <map>
#include <ctime>

#include "LPAstar.h"
#include "DStarLite.h"
#include "gridworld.h"

LpaStar::LpaStar(int rows, int cols) {
	m_rows = rows;
	m_cols = cols;

	m_maze.resize(rows);
	for (int i = 0; i < rows; i++) {
		m_maze[i].resize(cols);
	}

	m_pStart = nullptr;
	m_pGoal = nullptr;
	m_pLast = nullptr;
}

void LpaStar::setStart(int row, int col) {
	m_pStart = &m_maze[row][col];
}

void LpaStar::setGoal(int row, int col) {
	m_pGoal = &m_maze[row][col];
}

void LpaStar::initialise() {
	m_U.empty();
	for (int i = 0; i < m_rows; i++) {
		for (int j = 0; j < m_cols; j++) {
			m_maze[i][j].g = INF;
			m_maze[i][j].rhs = INF;
		}
	}
	m_pStart->rhs = 0;
	calcKey(m_pStart);
	m_U.insert(m_pStart);

}

double LpaStar::calcH(MazeCell* s) {
	int diffY = abs(m_pGoal->row - s->row);
	int diffX = abs(m_pGoal->col - s->col);
	if (HEURISTIC == MANHATTAN) {
		s->h = fmax(diffY, diffX);
	} else { // EUCLIDEAN no need to calculate square root
		s->h = diffY * diffY + diffX * diffX;
	}

	return s->h;
}

void LpaStar::updateH() {
	for (int i = 0; i < m_rows; i++) {
		for (int j = 0; j < m_cols; j++)
			calcH(&m_maze[i][j]);
	}
}

double* LpaStar::calcKey(MazeCell* s) {
	s->key[1] = fmin(s->g, s->rhs);
	s->key[0] = s->key[1] + calcH(s);
	return s->key;
}

void LpaStar::updateKey() {
	for (int i = 0; i < m_rows; i++) {
		for (int j = 0; j < m_cols; j++) {
			calcKey(&m_maze[i][j]);
		}
	}
}

double LpaStar::minCPlusG(MazeCell* u) {
	MazeCell* succ[DIRECTIONS];
	getNeighbours(u, succ);
	double cg = INF;
	for (int i = 0; i < DIRECTIONS; i++) {
		MazeCell* s = succ[i];
		if (s == nullptr)
			continue;
		accessed_vertex[succ[i]] = 1;
		if (u->linkCost[i] + s->g < cg) {
			cg = u->linkCost[i] + s->g;
		}
	}

	return cg;
}

void LpaStar::getNeighbours(MazeCell* u, MazeCell** ptrPred) {
	for (int i = 0; i < DIRECTIONS; i++)
		ptrPred[i] = nullptr;

	int left = 1; // 0 is border
	int right = m_cols - 2; //m_cols-1 is border
	int top = 1;
	int bottom = m_rows - 2;

	for (int i = 0; i < DIRECTIONS; i++) {
		int x = u->col + neighbours[i].x;
		int y = u->row + neighbours[i].y;
		if (x >= left && x <= right && y >= top && y <= bottom
				&& m_maze[y][x].type != T_BLOCKED)
			ptrPred[i] = &m_maze[y][x];
	}
}

void LpaStar::updateVertex(MazeCell* u) {
	if (u == nullptr)
		return;
	accessed_vertex[u] = 1;
	if (!DStarLite::isSame(u, m_pStart)) {
		MazeCell* result = nullptr;
		u->rhs = minCPlusG(u);
	}

	m_U.remove(u->row, u->col);

	if (!DStarLite::equal(u->g, u->rhs)) {
		calcKey(u);
		m_U.insert(u);
	}
}

void LpaStar::computeShortestPath() {
	MazeCell* Pred[DIRECTIONS];
	int max_queue = 0;
	while ((DStarLite::lessThan(m_U.top()->key, calcKey(m_pGoal))
					|| !DStarLite::equal(m_pGoal->rhs, m_pGoal->g))) {
		if (m_U.size() > max_queue)
			max_queue = m_U.size();

		MazeCell* u = m_U.pop();
		accessed_vertex[u] = 1;
		getNeighbours(u, Pred);
		if (u->g > u->rhs) {
			u->g = u->rhs;
			for (int i = 0; i < DIRECTIONS; i++) {
				updateVertex(Pred[i]);
			}
		} else {
			u->g = INF;
			for (int i = 0; i < DIRECTIONS; i++) {
				updateVertex(Pred[i]);
			}
			updateVertex(u);
		}
	}
	cout << "remained U size is: " <<m_U.size()<<endl;
	cout << "max queue: " << max_queue<<endl;
}

MazeCell* LpaStar::simulateChange(MazeCell** succ){
	int row = 86; //86; //8
	int col = 93; //93;  //6

	grid_world.blockVertex(row, col);
	MazeCell* u = &m_maze[row][col];
	u->type = T_BLOCKED;
	getNeighbours(u, succ);
	for (int i=0; i < DIRECTIONS; i++) {
		MazeCell* s = succ[i];
		if (s != nullptr){
			//u is the in DIRECTIONS-1-i of its neighbor
			s->linkCost[DIRECTIONS-1-i] = INF;
		}
	}
	return u;
}

bool LpaStar::findPath() {
	cout<<"Search the shortest path LPA*."<<endl;
	accessed_vertex.clear();
	std::clock_t  start = std::clock();
	initialise();
	try {
		//the code should be in a endless loop in a production environment,
		//for demo purpose, we need to return for display the path.
		computeShortestPath();
		cout<<"Time in ms: "<<(std::clock() - start) / (double)(CLOCKS_PER_SEC / 1000) <<endl;
		cout<<"Total vertex accessed: " << accessed_vertex.size()<<endl;
		cout<<"expanded: "<< m_U.expanded_vertex.size()<<endl;

		//second time
		/*
		m_U.expanded_vertex.clear();
		accessed_vertex.clear();
		MazeCell* succ[DIRECTIONS];
		MazeCell* u = simulateChange(succ);
		start = std::clock();
		for (int i=0;i <DIRECTIONS; i++){
			MazeCell* s = succ[i];
			updateVertex(s);
		}

		computeShortestPath();
		cout<<"Time in ms: "<<(std::clock() - start) / (double)(CLOCKS_PER_SEC / 1000) <<endl;
		cout<<"Total vertex accessed: " << accessed_vertex.size()<<endl;
		cout<<"expanded: "<< m_U.expanded_vertex.size()<<endl;
		*/
		return true;
	} catch (exception & e) {
		cout << "Standard exception: " << e.what() << endl;
	}

	return false;
}
