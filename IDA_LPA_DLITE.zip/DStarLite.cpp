#include "DStarLite.h"

#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <map>
#include <ctime>
#include "gridworld.h"

DStarLite::DStarLite(int rows, int cols) {
	m_rows = rows;
	m_cols = cols;
	m_maze.resize(rows);
	for (int i = 0; i < rows; i++) {
		m_maze[i].resize(cols);
	}

	m_km = 0;

	m_pStart = nullptr;
	m_pGoal = nullptr;
	m_pLast = nullptr;
}

void DStarLite::setStart(int row, int col){
	m_pStart = &m_maze[row][col];
}

void DStarLite::setGoal(int row, int col){
	m_pGoal = &m_maze[row][col];
}

void DStarLite::initialize() {
	m_U.empty();
	m_km = 0;
	for (int i = 1; i < m_rows-1; i++) {
		for (int j = 1; j < m_cols-1; j++) {
			m_maze[i][j].g = INF;
			m_maze[i][j].rhs = INF;
		}
	}

	m_pGoal->rhs = 0;
	calcKey(m_pGoal);
	m_U.insert(m_pGoal);
}

double DStarLite::calcH(MazeCell* s) {
	int diffY = abs(m_pStart->row - s->row);
	int diffX = abs(m_pStart->col - s->col);
	if (HEURISTIC == MANHATTAN) {
		s->h = fmax(diffY, diffX);
	} else { // EUCLIDEAN no need to calculate square root
		s->h = diffY * diffY + diffX * diffX;
	}

	return s->h;
}

void DStarLite::updateH(){
	for (int i=0; i<m_rows; i++){
		for (int j=0; j<m_cols; j++)
			calcH(&m_maze[i][j]);
	}
}

double* DStarLite::calcKey(MazeCell* s) {
	s->key[1] = fmin(s->g, s->rhs);
	s->key[0] = fmin(s->g, s->rhs + calcH(s) + m_km);
	return s->key;
}

void DStarLite::updateKey(){
	for (int i=0; i<m_rows; i++){
		for (int j=0; j<m_cols; j++){
			calcKey(&m_maze[i][j]);
		}
	}
}

bool DStarLite::lessThan(double key1[2], double key2[2]) {
	if (equal(key1[0], key2[0]))
		return key1[1] < key2[1];

	return key1[0] < key2[0];
}

bool DStarLite::equal(double d1, double d2) {
	return (abs(d1 - d2) < 0.00001);
}

void DStarLite::copyKey(double* targetKey, double* sourceKey) {
	targetKey[0] = sourceKey[0];
	targetKey[1] = sourceKey[1];
}

bool DStarLite::isSame(MazeCell* v1, MazeCell* v2) {
	if (v1 == nullptr || v2 == nullptr)
		return false;

	return v1->equals(v2);
}

//return the blocked cell and all its successors
MazeCell* DStarLite::simulateChange(MazeCell** succ){
	int row = 86; //86; //8
	int col = 77; //77;  //6

	grid_world.blockVertex(row, col);
	MazeCell* u = &m_maze[row][col];
	u->type = T_BLOCKED;
	getNeighbours(u, succ);
	for (int i=0; i < DIRECTIONS; i++) {
		MazeCell* s = succ[i];
		if (s != nullptr){
			//u is the in DIRECTIONS-1-i of its neighbor
			s->linkCost[DIRECTIONS-1-i] = INF;
		}
	}
	return u;
}

void DStarLite::getNeighbours(MazeCell* u, MazeCell** ptrPred) {
	for (int i = 0; i < DIRECTIONS; i++)
		ptrPred[i] = nullptr;

	int left = 1; // 0 is border
	int right = m_cols - 2; //m_cols-1 is border
	int top = 1;
	int bottom = m_rows - 2;

	for (int i = 0; i < DIRECTIONS; i++) {
		int x = u->col + neighbours[i].x;
		int y = u->row + neighbours[i].y;
		if (x >= left && x <= right && y >= top && y <= bottom
				&& m_maze[y][x].type != T_BLOCKED)
			ptrPred[i] = &m_maze[y][x];
	}
}

double DStarLite::minCPlusG(MazeCell* u, MazeCell** moveTo) {
	MazeCell* succ[DIRECTIONS];
	getNeighbours(u, succ);
	double cg = INF;
	for (int i = 0; i < DIRECTIONS; i++) {
		MazeCell* s = succ[i];
		if (s == nullptr)
			continue;
		accessed_vertex[succ[i]] = 1;
		if (u->linkCost[i] + s->g < cg)
		{
			cg = u->linkCost[i] + s->g;
			*moveTo = s;
		}
	}

	return cg;
}

void DStarLite::updateVertex(MazeCell* u) {
	if (u == nullptr)
		return;
	accessed_vertex[u] = 1;
	if (!isSame(u, m_pGoal)) {
		MazeCell* result = nullptr;
		u->rhs = minCPlusG(u, &result);
	}

	m_U.remove(u->row, u->col);

	if (!equal(u->g, u->rhs)) {
		calcKey(u);
		m_U.insert(u);
	}
}

void DStarLite::computeShortestPath() {
	double key_old[2];
	MazeCell* Pred[DIRECTIONS];
	int max_queue = 0;
	while (m_U.size() > 0
			&& (lessThan(m_U.top()->key, calcKey(m_pStart))	|| !equal(m_pStart->rhs, m_pStart->g))) {
		if (m_U.size() > max_queue)
			max_queue = m_U.size();
		copyKey(key_old, m_U.top()->key);
		MazeCell* u = m_U.pop();
		accessed_vertex[u] = 1;
		if (lessThan(key_old, calcKey(u))) {
			m_U.insert(u);
		} else if (u->g > u->rhs) {
			u->g = u->rhs;
			getNeighbours(u, Pred);
			for (int i=0; i < DIRECTIONS; i++) {
				updateVertex(Pred[i]);
			}
		} else {
			u->g = INF;
			getNeighbours(u, Pred);
			for (int i=0; i < DIRECTIONS; i++) {
				updateVertex(Pred[i]);
			}
			updateVertex(u);
		}
	}
	cout << "remained U size is: " <<m_U.size()<<endl;
	cout << "max queue: " << max_queue<<endl;
}

bool DStarLite::findPath() {
	cout<<"Search the shortest path with D*Lite."<<endl;
	accessed_vertex.clear();
	m_pLast = m_pStart;
	std::clock_t  start = std::clock();
	initialize();
	try{
		//initial search
		computeShortestPath();
		cout <<"Initial time in ms: "<<(std::clock() - start) / (double)(CLOCKS_PER_SEC / 1000) <<endl;
		cout<<"Total vertex accessed: " << accessed_vertex.size()<<endl;
		cout<<"expanded: "<< m_U.expanded_vertex.size()<<endl;
		int move_count = 0;
		while (!isSame(m_pStart, m_pGoal)) {
			//there is no known path
			if (equal(m_pStart->g, INF))
				return false;

			minCPlusG(m_pStart, &m_pStart);
			move_count++;


			//simulate a change to the map and trigger the second search after moving 1 step
			//change the grid to 102x102
			/*
			if (move_count == 1){

				cout <<"vertex size is: "<<accessed_vertex.size()<<endl;
				start = std::clock();
				//block one cell
				MazeCell* succ[DIRECTIONS];
				MazeCell* u = simulateChange(succ);

				accessed_vertex.clear();
				m_U.expanded_vertex.clear();
				m_km += calcH(m_pLast);
				m_pLast = m_pStart;
				for (int i=0;i <DIRECTIONS; i++){
					MazeCell* s = succ[i];
					updateVertex(s);
				}
				computeShortestPath();
				cout <<"Second time in ms: "<<(std::clock() - start) / (double)(CLOCKS_PER_SEC / 1000) <<endl;
				cout<<"Total vertex accessed: " << accessed_vertex.size()<<endl;
				cout<<"expanded: "<< m_U.expanded_vertex.size()<<endl;
			}*/
		}
		return true;
	}
	catch (exception & e) {
		cout << "Standard exception: " << e.what() << endl;
	}
	return false;
}
