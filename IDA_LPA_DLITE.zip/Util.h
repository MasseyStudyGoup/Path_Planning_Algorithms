#ifndef __UTIL_H__
#define __UTIL_H__

#include "globalVariables.h"

int getKey();

void testPriorityQueue();
void test();

/////////////////////////////////////////////////////////////
#endif
